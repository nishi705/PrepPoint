package FairWork.OOPsDemoForFactory.Dependencies;

public interface Query {
    void execute();
}
