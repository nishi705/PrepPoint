package FairWork.ParkingLot.models.enums;

public enum GateType {
    ENTRY,
    EXIT
}
