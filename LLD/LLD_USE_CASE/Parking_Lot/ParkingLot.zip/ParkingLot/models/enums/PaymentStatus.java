package FairWork.ParkingLot.models.enums;

public enum PaymentStatus {
    SUCCESS,
    IN_PROGRESS,
    FAILURE
}
