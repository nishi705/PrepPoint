package FairWork.ParkingLot.models.enums;

public enum ParkingSlotStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE
}
