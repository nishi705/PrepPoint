package FairWork.ParkingLot.models.enums;

public enum PaymentMode {
    ONLINE,
    OFFLINE
}
