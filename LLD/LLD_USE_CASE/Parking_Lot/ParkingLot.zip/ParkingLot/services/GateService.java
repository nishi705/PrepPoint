package FairWork.ParkingLot.services;

import FairWork.ParkingLot.models.Gate;

public class GateService {
    public Gate getGateById(Long gateId){
        // make a hit to gate repository and get gate
        return null;
    }
}
