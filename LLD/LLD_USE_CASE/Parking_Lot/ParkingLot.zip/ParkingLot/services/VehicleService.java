package FairWork.ParkingLot.services;

import FairWork.ParkingLot.models.Vehicle;
import FairWork.ParkingLot.models.enums.VehicleType;

public class VehicleService {
    public Vehicle getVehicleByVehicleNumber(String vehicleNumber){
        // make a call to vehicle repository and return the vehicle
        return null;
    }

    public Vehicle registerVehicle(String vehicle, VehicleType vehicleType){
        // make a call to vehicle repository (which will insert a new vehicle and return the new inserted vehicle)
        return null;
    }
}
