package FairWork.ParkingLot.repositories;

import FairWork.ParkingLot.models.ParkingLot;
import FairWork.ParkingLot.models.ParkingSlot;

import java.util.List;

public class ParkingSlotRepository {
    public List<ParkingSlot> getAllParkingSlotsByParkingLot(ParkingLot parkingLot){
        return null;
    }
}
