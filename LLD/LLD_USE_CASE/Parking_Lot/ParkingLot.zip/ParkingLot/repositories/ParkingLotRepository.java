package FairWork.ParkingLot.repositories;

import FairWork.ParkingLot.models.Gate;
import FairWork.ParkingLot.models.ParkingLot;

public class ParkingLotRepository {
    public ParkingLot getParkingLotByGate(Gate gate){
        // query required
        return null;
    }
}
