package FairWork.ParkingLot.dtos;

public enum ResponseStatus {
    FAILURE,
    SUCCESS
}
