package FairWork.ParkingLot.dtos;

import FairWork.ParkingLot.models.enums.VehicleType;

public class GenerateTicketRequestDTO {
    private Long gateId;
    // the vehicle might be visiting the parking lot for first time and hence not in db
    private String vehicleNumber;
    private VehicleType vehicleType;

    public Long getGateId() {
        return gateId;
    }

    public void setGateId(Long gateId) {
        this.gateId = gateId;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }
}
