package FairWork.TicTacToe.exceptions;

public class InvalidGameArgumentsException extends Exception {
    public InvalidGameArgumentsException(String message){
        super(message);
    }
}
