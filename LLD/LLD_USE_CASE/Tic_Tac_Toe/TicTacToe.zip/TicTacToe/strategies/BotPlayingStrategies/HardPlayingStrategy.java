package FairWork.TicTacToe.strategies.BotPlayingStrategies;

import FairWork.TicTacToe.models.Board;
import FairWork.TicTacToe.models.Move;
import FairWork.TicTacToe.models.Player;

public class HardPlayingStrategy implements BotPlayingStrategy{
    public Move decideMove(Player player, Board board){
        return null;
    }
}
