package FairWork.TicTacToe.models;

public enum BotDifficultyLevel {
    Easy,
    Medium,
    Hard
}
