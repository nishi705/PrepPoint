package FairWork.TicTacToe.models;

public enum GameState {
    InProgress,
    End_In_Draw,
    End_In_Result
}
