package com.example.splitwise.dtos;

public enum StatusCode {
    SUCCESS,
    FAILURE
}
