package com.scaler.bmsfairmysql.models.enums;

public enum SeatStatus {
    AVAILABLE,
    MAINTENANCE,
    BOOKED,
    LOCKED
}
