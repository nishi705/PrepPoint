package com.scaler.bmsfairmysql.models.enums;

public enum Language {
    HINDI,
    ENGLISH,
    TAMIL
}
