package com.scaler.bmsfairmysql.models.enums;

public enum Role {
    CUSTOMER,
    THEATRE_ADMIN,
    BMS_ADMIN
}
