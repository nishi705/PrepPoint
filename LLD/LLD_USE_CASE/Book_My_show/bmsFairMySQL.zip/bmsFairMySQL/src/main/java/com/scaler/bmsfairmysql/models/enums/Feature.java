package com.scaler.bmsfairmysql.models.enums;

public enum Feature {
    TWO_D,
    THREE_D,
    DOLBY
}
