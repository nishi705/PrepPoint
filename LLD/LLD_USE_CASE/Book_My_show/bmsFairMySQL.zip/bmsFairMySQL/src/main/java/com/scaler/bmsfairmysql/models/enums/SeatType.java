package com.scaler.bmsfairmysql.models.enums;

public enum SeatType {
    SILVER, // 1
    GOLD, // 2
    PLATINUM // 3
}
