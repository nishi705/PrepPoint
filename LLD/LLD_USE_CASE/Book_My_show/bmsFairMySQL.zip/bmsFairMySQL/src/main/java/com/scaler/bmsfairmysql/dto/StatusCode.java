package com.scaler.bmsfairmysql.dto;

public enum StatusCode {
    SUCCESS,
    FAILURE,
}
