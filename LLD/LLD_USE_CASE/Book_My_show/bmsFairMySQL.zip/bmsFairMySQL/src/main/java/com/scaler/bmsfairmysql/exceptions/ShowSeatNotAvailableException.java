package com.scaler.bmsfairmysql.exceptions;

public class ShowSeatNotAvailableException extends  Exception {
    public ShowSeatNotAvailableException(String message){
        super(message);
    }
}
