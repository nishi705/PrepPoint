package com.scaler.bmsfairmysql.models.enums;

public enum PaymentProvider {
    STRIPE,
    RAZORPAY,
    PAYU
}
