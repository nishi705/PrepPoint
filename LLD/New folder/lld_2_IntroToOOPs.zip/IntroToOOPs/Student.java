package FairWork.IntroToOOPs;

public class Student {
    int age;
    String name;
    double psp;

    void mockInterviews(){
        System.out.println(name + " gives an interview");
    }
}
