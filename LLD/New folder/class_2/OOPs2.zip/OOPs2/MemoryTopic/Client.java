package FairWork.OOPs2.MemoryTopic;

public class Client {
    public static void main(String[] args) {
        int age = 10;
        Point p = new Point();
        p.x = 10;
        p.y = 20;

        System.out.println(age);
        System.out.println(p);
        System.out.println(p.x);
        System.out.println(p.y);
    }
}
