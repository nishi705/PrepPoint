package FairWork.OOPs2.MemoryTopic;

public class Point {
    int x;
    int y;
}
