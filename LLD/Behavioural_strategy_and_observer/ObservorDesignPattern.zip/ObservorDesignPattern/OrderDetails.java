package FairWork.ObservorDesignPattern;

public class OrderDetails {
    int orderId;
    String address;
    int prdId;
    int qty;
    int price;
}
