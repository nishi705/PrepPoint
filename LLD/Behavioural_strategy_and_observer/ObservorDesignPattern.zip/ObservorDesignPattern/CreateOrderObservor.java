package FairWork.ObservorDesignPattern;

public interface CreateOrderObservor {
    void orderCreated(OrderDetails od);
}
