package com.authenticatorsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticatorsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
