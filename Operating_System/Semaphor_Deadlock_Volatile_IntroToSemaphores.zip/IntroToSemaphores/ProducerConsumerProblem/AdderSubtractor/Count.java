package FairWork.IntroToSemaphores.ProducerConsumerProblem.AdderSubtractor;

import java.util.concurrent.atomic.AtomicInteger;

public class Count {
    AtomicInteger value = new AtomicInteger(0);
}
