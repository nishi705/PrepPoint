package FairWork.IntroToSynchronization.AdderSubtractor;

public class Count {
    int value = 0;
}
