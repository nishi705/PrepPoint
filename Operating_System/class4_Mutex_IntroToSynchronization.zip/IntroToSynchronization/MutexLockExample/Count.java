package FairWork.IntroToSynchronization.MutexLockExample;

public class Count {
    int value = 0;
}
