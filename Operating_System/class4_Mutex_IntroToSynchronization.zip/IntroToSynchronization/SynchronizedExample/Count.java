package FairWork.IntroToSynchronization.SynchronizedExample;

public class Count {
    int value = 0;
}
